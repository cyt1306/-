<?php
//学号：21181306 姓名：陈雨婷
   header("content-type:text/html;charset=utf-8");
   $id = $_GET["no"];
   $handle = fopen("members.txt","r");
   while(!feof($handle))
   {  
        $data = fgets($handle,4096);
		if(substr_count($data,$id)>0)
		{
			$user = json_decode($data);
			echo "该会员已注册：<br/>编号：$user->bh<br/>姓名：$user->xm<br/>性别：$user->xb<br/>";
		}
   }
   echo " ";
   fclose($handle);
?>
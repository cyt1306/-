<?php
//学号：21181306 姓名：陈雨婷
   header("content-type:text/html;charset=utf-8");
   $id = $_POST["uid"];
   $na = $_POST["name"];
   $se = $_POST["sex"];
   $arr = array('bh'=>$id,'xm'=>$na,'xb'=>$se);
   $json = json_encode($arr);
   $flag = file_put_contents("members.txt",$json.PHP_EOL,FILE_APPEND);
   if($flag)
   {
	   echo "会员信息如下：<br/>";
	   echo "编号：".$id."<br/>";
	   echo "姓名：".$na."<br/>";
	   echo "性别：".$se."<br/>";
	   echo "会员信息已保存。"."<a href='http://localhost/webpg05-21181306/membereg.html'>返回</a>";
   }
   else
   {
	   echo "会员信息未保存"."<a href='http://localhost/webpg05-21181306/membereg.html'>返回</a>";
   }
?>
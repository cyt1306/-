<?php
//学号：21181306 姓名：陈雨婷
   header("content-type:text/html;charset=utf-8");
   echo "&#12288;&#12288;会员信息一览表";
   echo "<br/>";
   echo "<table border='1'>";
   echo "<tr bgcolor='lightgray'><th>序号</th><th>编号</th><th>姓名</th><th>性别</th></tr>";
   $handle = fopen("members.txt","r");
   $i = 1;
   while(!feof($handle))
   {
	   $js = fgets($handle,4096);
	   $user = json_decode($js);
	   if(!empty($user))
	   {
		   if($i%2 == 1)
		   {
		       echo "<tr>";
	           echo "<td>$i</td>";
	           echo "<td>$user->bh</td>";
	           echo "<td>$user->xm</td>";
	           echo "<td>$user->xb</td>";
		   }
		   else
		   {
			   echo "<tr bgcolor='lightgray'>";
	           echo "<td>$i</td>";
	           echo "<td>$user->bh</td>";
	           echo "<td>$user->xm</td>";
	           echo "<td>$user->xb</td>";
		   }
		   $i = $i + 1;
	   }
   }
   echo "</table>";
   fclose($handle);
   echo "<a href='http://localhost/webpg05-21181306/membereg.html'>返回</a>";
?>